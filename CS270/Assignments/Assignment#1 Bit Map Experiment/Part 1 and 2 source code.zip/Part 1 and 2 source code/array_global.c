/*
Andrew Plum
Professor Bolden
CS 270
10/7/22
*/

    /*
    ***Assignment #1 - array_global.c***
    */

// Globals

#define arr_size 10
int arr[arr_size];
