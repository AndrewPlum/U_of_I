/*
Andrew Plum
Professor Bolden
CS 270
10/7/22
*/

    /*
    ***Assignment #1 - array_global.h***
    */

// Extern of globals

extern const int arr_size;
extern int arr[];

