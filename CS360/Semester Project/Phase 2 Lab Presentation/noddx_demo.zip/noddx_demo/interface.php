<?php
enum Rule : int {
    case Given = 0;
    case Reflexivity = 1;
    case Transitivity = 2;
    case Augmentation = 3;
    case Union = 4;
    case Decomposition = 5;
    case PseudoTransitivity = 6;
}

function ValidFormatCheck ($sideleft, $sideright, $justification, $basis) {
    if ($sideright && !$sideleft){
        return false;
    }
    switch ($justification) {
        case Rule::Given:
            return (count($basis) == 1);

        case Rule::Reflexivity:
            return (count($basis) == 0);

        case Rule::Transitivity:
            return (count($basis) == 2);

        case Rule::Augmentation:
            return (count($basis) == 1);

        case Rule::Union:
            return (count($basis) == 2);

        case Rule::Decomposition:
            return (count($basis) == 1);

        case Rule::PseudoTransitivity:
            return (count($basis) == 2);

        default:
            echo "Error Invalid Rule";
            return false;
    }
}

function CycleFormatCheckv ($table) {
    for ($i = 0; $i < count($table); $i++) {
        if (ValidFormatCheck ($table[$i]["sideleft"], $table[$i]["sideright"], $table[$i]["justification"], $table[$i]["basis"]) == false)
        {
            return false;
        }
    }
    return true;
}

function GivenCheck ($row,$table) { #$fd["basis"]<$fd["index"] &&
    $ref = $row["basis"];
    return (($table[$row["basis"]]["sideleft"] == $row["sideleft"]) && ($table[$row["basis"]]["sideright"] == $row["sideright"]));
}

function ReflexivityCheck ($row) {
    return ($row["rightside"] == $row["rightside"] & $row["leftside"]);
}

// function AugmentationCheck ($row, $tabley) {
//     return ($row[] == $row[]);
// }

$fd1 = array(
    "sideleft" => array("A"),
    "sideright" => array("B"),
    "justification" => Rule::Given,
    "basis" => array(1)
);

$fd2 = array(
    "sideleft" => array("B"),
    "sideright" => array("C"),
    "justification" => Rule::Reflexivity,
    "basis" => array()
);

$fd3 = array(
    "sideleft" => array("BC"),
    "sideright" => array("AD"),
    "justification" => Rule::Transitivity,
    "basis" => array(1,2)
);

$fd4 = array(
    "sideleft" => array("BCD"),
    "sideright" => array("E"),
    "justification" => Rule::Union,
    "basis" => array(1,2)
);

$fd5 = array(
    "sideleft" => array("AB"),
    "sideright" => array("F"),
    "justification" => Rule::Decomposition,
    "basis" => array(2)
);

print_r($fd5);

$fdarray = array(
    $fd1,
    $fd2,
    $fd3,
    $fd4,
    $fd5
);

/*
ValidFormatCheck($fd1["sideleft"], $fd1["sideright"], $fd1["justification"], $fd1["basis"]);
ValidFormatCheck($fd2["sideleft"], $fd2["sideright"], $fd2["justification"], $fd2["basis"]);
ValidFormatCheck($fd3["sideleft"], $fd3["sideright"], $fd3["justification"], $fd3["basis"]);
ValidFormatCheck($fd4["sideleft"], $fd4["sideright"], $fd4["justification"], $fd4["basis"]);
ValidFormatCheck($fd5["sideleft"], $fd5["sideright"], $fd5["justification"], $fd5["basis"]);
*/

// Call the function for each functional dependency


if(!CycleFormatCheck($table)){
    echo "False";
}

?>