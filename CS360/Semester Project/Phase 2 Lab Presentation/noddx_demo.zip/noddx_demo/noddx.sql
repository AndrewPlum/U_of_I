-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2023 at 01:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `noddx`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `entries01`
--

CREATE TABLE `entries01` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `linenum` int(11) NOT NULL,
  `sideleft` int(10) UNSIGNED ZEROFILL NOT NULL DEFAULT 0000000000 COMMENT 'binary encoding of attribute set',
  `sideright` int(10) UNSIGNED ZEROFILL NOT NULL DEFAULT 0000000000 COMMENT 'binary encoding of attribute set',
  `rule` int(11) NOT NULL DEFAULT 0 COMMENT 'enum for FD rules',
  `basis1` int(11) DEFAULT NULL,
  `basis2` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entries01`
--

INSERT INTO `entries01` (`id`, `submission_id`, `linenum`, `sideleft`, `sideright`, `rule`, `basis1`, `basis2`) VALUES
(0, 0, 1, 0000000001, 0000000004, 2, 1, 2),
(1, 0, 2, 0000000012, 0000000016, 5, 4, NULL),
(2, 0, 3, 0000000001, 0000000012, 4, 4, 5),
(3, 0, 4, 0000000001, 0000000016, 2, 6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `entries02`
--

CREATE TABLE `entries02` (
  `id` int(11) NOT NULL,
  `submission_id` int(11) NOT NULL,
  `list` int(10) UNSIGNED ZEROFILL NOT NULL DEFAULT 0000000000 COMMENT 'binary encoding of set of attributes',
  `rule` int(11) NOT NULL DEFAULT 0 COMMENT 'enum for FD rules',
  `basis` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `assignment_id` int(11) DEFAULT NULL,
  `name` text NOT NULL,
  `type` int(11) NOT NULL,
  `data1` int(11) DEFAULT NULL COMMENT 'auxiliary data, for LCoF this is final left, for AC this is the initial set ',
  `data2` int(11) DEFAULT NULL COMMENT 'For LCoF this is final right side.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `assignment_id`, `name`, `type`, `data1`, `data2`) VALUES
(0, NULL, 'Using the Logical Consequences of \nF: {A->B, B->C, A->D, CD->AE}\nShow that\nA->E', 1, 1, 16),
(1, NULL, 'Using the Logical Consequences of \r\nF: {A->B, B->C, A->D, CD->AE}\r\nShow that\r\nBD->AC', 1, 10, 5);

-- --------------------------------------------------------

--
-- Table structure for table `q_entries`
--

CREATE TABLE `q_entries` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `numline` int(11) NOT NULL,
  `sideleft` int(10) UNSIGNED ZEROFILL NOT NULL DEFAULT 0000000000,
  `sideright` int(10) UNSIGNED ZEROFILL NOT NULL DEFAULT 0000000000
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `q_entries`
--

INSERT INTO `q_entries` (`id`, `question_id`, `numline`, `sideleft`, `sideright`) VALUES
(0, 0, 1, 0000000001, 0000000002),
(1, 1, 1, 0000000001, 0000000002),
(2, 0, 2, 0000000002, 0000000004),
(3, 1, 2, 0000000002, 0000000004),
(4, 0, 3, 0000000001, 0000000008),
(5, 1, 3, 0000000001, 0000000008),
(6, 0, 4, 0000000012, 0000000017),
(7, 1, 4, 0000000012, 0000000017);

-- --------------------------------------------------------

--
-- Table structure for table `submissions`
--

CREATE TABLE `submissions` (
  `id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `question_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `feedback` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `submissions`
--

INSERT INTO `submissions` (`id`, `timestamp`, `question_id`, `user_id`, `feedback`) VALUES
(0, '2023-11-15 11:52:31', 0, NULL, NULL),
(1, '2023-11-15 12:03:08', 1, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entries01`
--
ALTER TABLE `entries01`
  ADD PRIMARY KEY (`id`),
  ADD KEY `e1SID` (`submission_id`);

--
-- Indexes for table `entries02`
--
ALTER TABLE `entries02`
  ADD PRIMARY KEY (`id`),
  ADD KEY `e2SID` (`submission_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Assignment-ID` (`assignment_id`);

--
-- Indexes for table `q_entries`
--
ALTER TABLE `q_entries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `qeQID` (`question_id`);

--
-- Indexes for table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subQID` (`question_id`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `entries01`
--
ALTER TABLE `entries01`
  ADD CONSTRAINT `e1SID` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `entries02`
--
ALTER TABLE `entries02`
  ADD CONSTRAINT `e2SID` FOREIGN KEY (`submission_id`) REFERENCES `submissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `questions`
--
ALTER TABLE `questions`
  ADD CONSTRAINT `Assignment-ID` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `q_entries`
--
ALTER TABLE `q_entries`
  ADD CONSTRAINT `qeQID` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `submissions`
--
ALTER TABLE `submissions`
  ADD CONSTRAINT `subQID` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
