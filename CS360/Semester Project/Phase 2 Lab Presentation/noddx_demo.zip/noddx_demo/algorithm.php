<?php

// Define the functional dependencies as arrays
enum Rule:int {
    case Given = 0;
    case Reflexivity = 1;
    case Transitivity = 2;
    case Augmentation = 3;
    case Union = 4;
    case Decomposition = 5;
    case PseudoTransitivity = 6;
}

function Sixteen_bit_to_list($set){
    $list = "";
    if($set & 0x0001) $list .= "A";
    if($set & 0x0002) $list .= "B";
    if($set & 0x0004) $list .= "C";
    if($set & 0x0008) $list .= "D";
    if($set & 0x0010) $list .= "E";
    if($set & 0x0020) $list .= "F";
    if($set & 0x0040) $list .= "G";
    if($set & 0x0080) $list .= "H";
    if($set & 0x0100) $list .= "I";
    if($set & 0x0200) $list .= "J";
    if($set & 0x0400) $list .= "K";
    if($set & 0x0800) $list .= "L";
    if($set & 0x1000) $list .= "M";
    if($set & 0x2000) $list .= "N";
    if($set & 0x4000) $list .= "O";
    if($set & 0x8000) $list .= "P";
    return $list;
}

function GetRow($row_number, $user_entries, $question_entries){
    if($row_number <= count($question_entries)){
        for($i = 0; $i < count($question_entries); $i++){
            if($question_entries[i]["numline"] == $row_number){
                return $question_entries[i];
            }
        }
    }else{
        if($row_number <= count($question_entries) + count($user_entries)){
            for($i = 0; $i < count($user_entries); $i++){
                if($user_entries[i]["numline"] == $row_number-count($question_entries)){
                    return $user_entries[i];
                }
            }
        }
    }
    die("oops");
}

function GivenCheck($fd_check, $fd_ref1){
    return $fd_check["leftside"] == $fd_ref1["leftside"] && $fd_check["rightside"] == $fd_ref1["rightside"];
}

function ReflexivityCheck($fd_check){
    return $fd_check["rightside"] == ($fd_check["leftside"] & $fd_check["rightside"]);
}

function TransitivityCheck($fd_check, $fd_ref1, $fd_ref2) {
    $forward = $fd_check["leftside"] == $fd_ref1["leftside"] && $fd_ref2["leftside"] == $fd_ref1["rightside"] && $fd_ref2["rightside"] == $fd_check["rightside"];
    $reverse = $fd_check["leftside"] == $fd_ref2["leftside"] && $fd_ref1["leftside"] == $fd_ref2["rightside"] && $fd_ref1["rightside"] == $fd_check["rightside"];
    return($forward || $reverse);
}

function UnionCheck($fd_check, $fd_ref1, $fd_ref2){
    $left_equal = $fd_check["leftside"] == $fd_ref1["leftside"] && $fd_ref1["leftside"] == $fd_ref2["leftside"];
    $right_union = $fd_check["rightside"] == ($fd_ref1["rightside"] | $fd_ref2["rightside"]);
    return $left_equal && $right_union;
}

function DecompositionCheck($fd_check, $fd_ref1){
    $left_equal = $fd_check["leftside"] == $fd_ref1["leftside"];
    $right_subset = $fd_check["rightside"] == ($fd_check["rightside"] & $fd_ref1["rightside"]);
    return $left_equal && $right_subset;
}

function AugmentationCheck($fd_check, $fd_ref1){
    $r1_subeq_rx = (($fd_check["rightside"] & $fd_ref1["rightside"]) == $fd_ref1["rightside"]);
    $l1_subeq_lx = (($fd_check["leftside"] & $fd_ref1["leftside"]) == $fd_ref1["leftside"]); 
    $difference = $fd_check["rightside"] ^ $fd_ref1["rightside"];
    $diff_subeq_lx = (($fd_check["leftside"] & $difference) == $difference);
    
    return $r1_subeq_rx && $l1_subeq_lx && $diff_subeq_lx;
}

/* Strict Pseudo-Transitivity - check to see if correct - should have interchangeable references
    R1 < L2
    LX == L1 | R1 ^ L2 
    RX == R2
*/
function PseudoTransitivityCheck($fd_check, $fd_ref1, $fd_ref2){ 
    $condition1a = (($fd_ref2["leftside"] & $fd_ref1["rightside"]) == $fd_ref1["rightside"]);
    $condition2a = ($fd_check["leftside"] == ($fd_ref1["leftside"] | ($fd_ref1["rightside"] ^ $fd_ref2["leftside"])));
    $condition3a = ($fd_check["rightside"] == $fd_ref2["rightside"]);
    
    $condition1b = (($fd_ref1["leftside"] & $fd_ref2["rightside"]) == $fd_ref2["rightside"]);
    $condition2b = ($fd_check["leftside"] == ($fd_ref2["leftside"] | ($fd_ref2["rightside"] ^ $fd_ref1["leftside"])));
    $condition3b = ($fd_check["rightside"] == $fd_ref1["rightside"]);
    
    return ($condition1a && $condition2a && $condition3a) || ($condition1b && $condition2b && $condition3b);     
}

/* Generalized Logical Consequences (Given LR1,LR2,LX, maximize RX)
    LX > L1 | ((R1 & L2) ^ L2)
    RX < R1 | R2 | LX

    function logical(L1, R1, L2, R2, LX, RX)
    return (((L2 ^ (R1 & L2) | L1) == (LX & (L2 ^ (R1 & L2) | L1)) 
    || (L1 ^ (R2 & L1) | L2) == (LX & L1 ^ (R2 & L1) | L2)) 
    && RX == (RX & (R1 | R2 | LX)))
*/
function logical($fd_check, $ref1, $ref2){
    $L1_plus_L2_less_R1 = $ref2["leftside"] ^ ($ref1["rightside"] & $ref2["leftside"]) | $ref1["leftside"];
    $L2_plus_L1_less_R2 = $ref1["leftside"] ^ ($ref2["rightside"] & $ref1["leftside"]) | $ref2["leftside"];

    $LX_superset_a = $L1_plus_L2_less_R1 == ($fd_check["leftside"] & $L1_plus_L2_less_R1);
    $LX_superset_b = $L2_plus_L1_less_R2 == ($fd_check["leftside"] & $L2_plus_L1_less_R2);

    $RX_subset = $fd_check["rightside"] == ($fd_check["rightside"] & ($ref1["rightside"] | $ref2["rightside"] | $fd_check["leftside"]));
    return (($LX_superset_a || $LX_superset_b) && $RX_subset);
}

function EntryValidation($row, $user_entries, $question_entries){ // 0 = user success, 1 = user check fail, 2 = user format fail, 3 = sanityfail
    /*
    $basis = GetNumRefs($row);
    if($basis <= 2){
        if($basis>1){
            $ref2_row = GetRow(GetRef2($row), $user_entries, $question_entries);
        }
        if($basis>0){
            $ref1_row = GetRow(GetRef1($row), $user_entries, $question_entries);
        }else return 3; //somehow, there are less than 0 reference rows.
    }else return 2; //user put too many reference rows
    */

    $basis = 0;
    if($row["basis-1"]){
        if($row["basis1"] < $row["numline"] + count($question_entries)){
            $ref1_row = GetRow($row["basis1"], $user_entries, $question_entries);
            $basis++;
        }else return 3;
        if($row["basis-2"]){
            if($row["basis2"] < $row["numline"] + count($question_entries)){
                $ref2_row = GetRow($row["basis2"], $user_entries, $question_entries);
                $basis++;
            }else return 3;
        }
    }

    switch ($row["rule"]) {
        case Rule::Given:
            return $basis == 1 ? (GivenCheck($row, $ref1_row) ? 0 : 1) : 2;
        case Rule::Reflexivity:
            return $basis == 0 ? (ReflexivityCheck($row) ? 0 : 1) : 2;
        case Rule::Transitivity:
            return $basis == 2 ? (TransitivityCheck($row, $ref1_row, $ref2_row) ? 0 : 1) : 2;
        case Rule::Augmentation:
            return $basis == 1 ? (AugmentationCheck($row, $ref1_row) ? 0 : 1) : 2;
        case Rule::Union:
            return $basis == 2 ? (UnionCheck($row, $ref1_row, $ref2_row) ? 0 : 1) : 2;
        case Rule::Decomposition:
            return $basis == 1 ? (DecompositionCheck($row, $ref1_row) ? 0 : 1) : 2;
        case Rule::PseudoTransitivity:
            return $basis == 2 ? (PseudoTransitivityCheck($row, $ref1_row, $ref2_row) ? 0 : 1) : 2;
        default:
            echo "Error Invalid Rule";
            return 3;
    }
}

// Database connections-------------------------------related to page.html

$host = "localhost"; // Change this to your database host
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$database = "noddx"; // Change this to your database name

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $database);

// Check for connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//Start of main connection payload----------------------------------------
//Given: sid = submission id
$sid = 1;

$sql = "SELECT * FROM submissions WHERE id = $sid";
$result = $conn->query($sql);
if(!$result) die("Query failed: " . $conn->error);
$submission = $result->fetch_assoc();

$qid = $submission[`question_id`];

$sql = "SELECT * FROM questions WHERE id = $qid";
$result = $conn->query($sql);
if(!$result) die("Query failed: " . $conn->error);
$question = $result->fetch_assoc();

$qtype = $question["type"];
if($qtype == 1 || $qtype == 2){
    $qentries = array();
    $sql = "SELECT * FROM qentries WHERE question_id = $qid";
    $result = $conn->query($sql);
    if(!$result) die("Query failed: " . $conn->error);
    while ($row = $result->fetch_assoc()) {
        $qentries[] = $row;
    }

    $entries = array();
    $entrytable = "entries0".$qtype;
    $sql = "SELECT * FROM $entrytable WHERE submission_id = $sid";
    $result = $conn->query($sql);
    if(!$result) die("Query failed: " . $conn->error);
    while ($row = $result->fetch_assoc()) {
        $entries[] = $row;
    }
    $conn->close();

    if($qtype == 1){
        $feedback = -1;
        $lastrow = $row;
        foreach($entries as $row){
            if($feedback = EntryValidation($row, $entries, $qentries)) break;  //assignment is intentional
            if($lastrow["numline"] < $row["numline"]) $lastrow = $row;
        }
        $qfinal = array(
            "sideleft" => $question[`data1`],
            "sideright" => $question[`data2`],
        );
        if($feedback == -1) $feedback = GivenCheck($lastrow, $qfinal)? 0 : 1;

        switch($feedback){
            case 0:
                echo "Correct!";
                return 0;
            case 1:
                echo "Incorrect. There's a problem with the logic.";
                return 1;
            case 2:
                echo "Incorrect. There's a problem with the submission format.";
                return 2;
            default:
                echo "Something is broken.";
                die;
        }
    }
    if($qtype == 2){


    }
}








// Attribute Closure Checking Algorithm

/*
// L1 > ((R1 & L2) ^ L2)
// RX =: R1 | R2 | L1
function logic_cons($ref1, $ref2){
    if($ref1["leftside"] == (($ref1["rightside"] & $ref2["leftside"]) ^ $ref2["leftside"] | $ref1["leftside"])){
        $new_right = ($ref1["leftside"] | $ref1["rightside"] | $ref2["rightside"]);
        return $new_right;
    }
    else return ($ref1["leftside"] | $ref1["rightside"]);
}

$qtype=2;
$qid;
$sid;

$qentries;
$entries;//(from entries02)

$bignum = 0;
foreach($entries as $row){
    if($row["numline"] > $bignum){
        $lastrow = $row;
    }
}
unset($row);

$current;//da given
do{
    $old = $current;
    foreach($qentries as $row){
        $current =
        
    }

}

*/


function AttributeClosureCheck($total_attr_rows, $fdarray, $attr_array, $init_attr){
    // have initial check to make sure everything in prove is in acceptable form
        // first row check
            // should be checking if the attributes in attribute closure match 
            // the attributes checked in the the first row 
            // the justification used should be Given
        // check if every row after the first has only 1 reference FD
    // second row onward check
    
    //$total_rows = count($attr_closure_table); // still need to assign total rows in the proof
    for($i = 1; $i < $total_attr_rows; $i++){
        $prev_attr;//$attr_array[i - 1]["checked_attr"]; // still need to assign
        $curr_attr;//$attr_array[i]["checked_attr"]; // still need to assign
    
        $common_attr = $curr_attr & $prev_attr;
        $diff_attr = $curr_attr ^ $prev_attr;
    
        if($common_attr & $fd_ref["leftside"] == $fd_ref["leftside"]){
            if($diff_attr == $fd_ref["rightside"]){
                break; // want to break out of both ifs continue on in the for loop without returning
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }
    
    // check if final answer at the end of the proof is the correct answer

    $condition = true;
    $prev_attr = $init_attr;
    $curr_attr = $init_attr;
    $next_attr = $init_attr;
    
    while(condition){
        $prev_attr = $curr_attr;
        for($i = 0; $i < count($fdarray); $i++){
            /*
            // could compare by decrement or by subset
            // this is by decrement
            for($j = 0; $j < ; $j){
                $curr = $curr - 1;
                if($curr_attr == $fdarray[i]["leftside"]){
                
                }
            }
            */
            // this is by subset
            if(($curr_attr & $fdarray[i]["leftside"]) == $fdarray[i]["leftside"]){
                $next_attr = $fdarray[i]["rightside"] | $next_attr;
            }
        }
        $curr_attr = $next_attr;
        $condition = $curr_attr != $prev_attr;
    }
    
    if($curr_attr != $attr_array[$total_attr_rows - 1]){ // $total_attr_rows - 1 should be the final row, -1 because attr_array indexed at 0
        return false; 
    }
    
    // retrun true if you haven't yet returned false
    
    return true; 
}



/*
$fd1 = array(
    "sideleft" => array("A"),
    "sideright" => array("B"),
    "justification" => Rule::Given,
    "basis" => array(1)
);

$fd2 = array(
    "sideleft" => array("B"),
    "sideright" => array("C"),
    "justification" => Rule::Reflexivity,
    "basis" => array()
);

$fd3 = array(
    "sideleft" => array("B", "C"),
    "sideright" => array("AD"),
    "justification" => Rule::Transitivity,
    "basis" => array(1,2)
);

$fd4 = array(
    "sideleft" => array("BCD"),
    "sideright" => array("E"),
    "justification" => Rule::Union,
    "basis" => array(1,2)
);

$fd5 = array(
    "sideleft" => array("AB"),
    "sideright" => array("F"),
    "justification" => Rule::Decomposition,
    "basis" => array(2)
);

$fdarray_initial = array(
    $fd1,
    $fd2,
    $fd3,
    $fd4,
    $fd5
);

$fdarray = array(
    $fd1,
    $fd2,
    $fd3,
    $fd4,
    $fd5
);
*/

//print_r($fdarray);

/*
print_r($fd1);
echo "<br>";
echo "<br>";
print_r($fd2);
echo "<br>";
echo "<br>";
print_r($fd3);
echo "<br>";
echo "<br>";
print_r($fd4);
echo "<br>";
echo "<br>";
print_r($fd5);
//*/

/*
$array = [1, "two", 3.14, true, ["apple", "banana"]];

foreach ($array as $element) {
    if (is_int($element)) {
        echo "$element is an integer.<br>";
    } elseif (is_string($element)) {
        echo "$element is a string.<br>";
    } elseif (is_float($element)) {
        echo "$element is a float.<br>";
    } elseif (is_bool($element)) {
        echo "$element is a boolean.<br>";
    } elseif (is_array($element)) {
        echo "An array is found.<br>";
    } else {
        echo "Unknown data type for $element.<br>";
    }
}
*/ 


?>
