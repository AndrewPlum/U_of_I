<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a href="<?php echo e(route('reset.password.get', $token)); ?>">Reset Password</a><?php /**PATH C:\xampp\htdocs\CS_360\Labs\Lab_6\Emailing_System\resources\views/emails/forgetPassword.blade.php ENDPATH**/ ?>