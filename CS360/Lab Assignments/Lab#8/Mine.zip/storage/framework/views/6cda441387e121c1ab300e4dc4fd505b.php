<!DOCTYPE html>
<html>
    <head>

    </head>
    <body>
        <h1>All the users: </h1>
        <table>
            <th>Id</th>
            <th>User's name</th>
            <th>User's email</th>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><?php echo e($user->usersname); ?></td>
                <td><?php echo e($user->usersemail); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </body>
    <script type="text/javascript">
      
    $(document).ready(function () {
       
       /* When click show user */
        $('body').on('click', '#show-user', function () {
          var userURL = $(this).data('url');
          $.get(userURL, function (data) {
              $('#userShowModal').modal('show');
              $('#user-id').text(data.id);
              $('#user-name').text(data.name);
              $('#user-email').text(data.email);
          })
       });
       
    });
  
</script>

<!--This is the more advanced version of the one in the video-->
<div class="auto-load text-center" style="display: none;">
    <div class="d-flex justify-content-center">
        <div class="spinner-border" role="status">
            <Span>Loading...</Span>
        </div>
    </div>
</div>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>      

    <script>
        var ENDPOINT = "<?php echo e(route(users)); ?>"
        var page = 1;
        $(".load-more-data").click(function(){
            page++;
            LoadMore(page);
        });

        function LoadMore(){
            $.ajax({
                url: ENDPOINT+"?pages"+page,
                datatype:  "html",
                type: "get",
                beforeSend: function(){
                    $('.auto-load').show();
                }
            })
            .done(function(response){
                console.log(response);
            })
            .fail(function (jqXHR, ajaxOptions,thrownError){
                console.log('Server Error Occured');
            });
        }

    </script>
</html><?php /**PATH C:\xampp\htdocs\lab8\resources\views/welcome.blade.php ENDPATH**/ ?>