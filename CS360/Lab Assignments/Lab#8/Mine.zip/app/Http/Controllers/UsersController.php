<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\users;

class UsersController extends Controller{
    public function index(Request $request){
        $users = users::paginate(2);
        if($request->ajax()){
            $view = view('users', compact('users'))->render();
            return response()->json(['html'=>$view]);
        }
        return view('users', compact('users'));
    }
    public function show($id)
    {
        $user = User::find($id);
        return response()->json($user);
    }
}
