<!DOCTYPE html>
<html>
<head>
    <title>User Directory</title>
</head>
<body>
    <h1>Users' List</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
        </tr>
        @foreach ($users as $user)
        <tr>
            <td>{{ $user->id }}</td>
            <td>{{ $user->username }}</td>
            <td>{{ $user->useremail }}</td>
        </tr>
        @endforeach
    </table>
</body>
<script type="text/javascript">
    $(document).ready(function() {
        $('body').on('click', '#show-user', function() {
            var userURL = $(this).data('url');
            $.get(userURL, function(data) {
                $('#userShowModal').modal('show');
                $('#user-id').text(data.id);
                $('#user-name').text(data.name);
                $('#user-email').text(data.email);
            });
        });
    });
</script>
<div class="auto-load text-center" style="display: none;">
    <div class="d-flex justify-content-center">
        <div class="spinner-border" role="status">
            <span>Loading Next</span>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script>
    var userEndpoint = "{{ route('users') }}";
    var currentPage = 1;
    $(".load-more-data").click(function() {
        currentPage++;
        loadMoreData(currentPage);
    });
    function loadMoreData(page) {
        $.ajax({
            url: userEndpoint + "?page=" + page,
            dataType: "html",
            type: "get",
            beforeSend: function() {
                $('.auto-load').show();
            }
        })
        .done(function(response) {
            console.log(response);
        })
        .fail(function(jqXHR, ajaxOptions, thrownError) {
            console.log('An error occurred on the server');
        });
    }
</script>
</html>
