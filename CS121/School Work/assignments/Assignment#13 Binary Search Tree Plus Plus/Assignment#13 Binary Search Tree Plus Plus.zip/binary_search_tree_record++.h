    /*
	Andrew Plum
	CS 121-01
	Assignment #13
	4/24/22
	*/

		// I did all of the regular assignment.

	/* binary_search_tree_record++.h */

#include<iostream>
#include<string>
using namespace std;

class record{
    public:
        string name;
        string data;
        // Could add these variables later if I want to:
        // string specie;
        // string gender;
        // string personality
        // ...
        // int happiness
    private:
};
